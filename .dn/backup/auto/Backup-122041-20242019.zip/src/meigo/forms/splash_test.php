<?php
namespace meigo\forms;

use php\gui\framework\AbstractForm;
use php\gui\event\UXEvent; 


class splash_test extends AbstractForm
{

    /**
     * @event button8.action 
     */
    function doButton8Action(UXEvent $e = null)
    {    
        
    }

}
